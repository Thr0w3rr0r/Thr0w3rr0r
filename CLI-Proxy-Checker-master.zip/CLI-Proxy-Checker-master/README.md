# CLI-Proxy-Checker WIP
Proxy connection checker /  proxy checker

## Why i made this.

I made this because i wanted to learn libcurl and multi threading :)

## Things to note:
When selecting the https option be sure to have OpenSSL, GnuTLS and NSS libcurl or else you will get: "A requested feature, protocol or option was not found built-in in this libcurl due to a build-time decision."
